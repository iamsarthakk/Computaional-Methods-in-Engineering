def round8(a):
    return round(a, 8)
def findError(curr_approx, prev_approx):
    diff = (curr_approx - prev_approx) *100
    if curr_approx == 0:
        return diff
    return diff/curr_approx 
def Romberg(f_string, a, b, eT):
    h = b-a
    from sympy import symbols, simplify
    x = symbols("x")
    function = simplify(f_string)
    f_of_a = function.subs(x, a)
    f_of_b = function.subs(x, b)
    extra_Value = (f_of_a + f_of_b)/2
    integrals = [[]]
    integrals[0].append(h*extra_Value)
    relat_err = 100 
    i = 1
    while abs(relat_err) > eT:
        h = h/2
        sum = 0
        from numpy import arange as Arrange
        x_arr =  Arrange(a+h, b, h)
        for k in  x_arr:
            sum = sum + function.subs(x, k)
        sum = sum + extra_Value
        integral = sum *h
        relat_err  = findError(integral, integrals[i-1][i-1])
        if abs(relat_err) <= eT:
            break
        integrals.append([integral])
        flag = -1 
        for j in range(1, i+1):
            i_2h_k = integrals[i-1][j-1]
            i_h_k =  integrals[i][j-1]
            i_h_k_pls_2 =  ((2**(j*2))*i_h_k -  i_2h_k)/((2**(j*2))-1)
            integrals[i].append(i_h_k_pls_2)
            relat_err = findError(i_h_k_pls_2, integrals[i][j-1])
            if abs(relat_err) <= eT:
                flag = 1
                break
        if flag == 1:
            break
        i = i+1
    x_arr =  Arrange(a, b+h, h)
    y_arr = []
    for i in x_arr:
        y_arr.append(function.subs(x, i))
    fop = raw_input("Enter the O/P file name without Extension : ")
    fop = fop.strip()+".txt"
    file  = open(fop, 'w')
    s = '\t\tRomberg Algorithm\n'
    z = len(integrals)
    zx = len(integrals[z-1])
    s = s + '\tI  = '+str(round8(integrals[z-1][zx-1]))+'\n'
    s = s+ 'Number of intervals : '+str(z+1)+'\n'
    s = s+'Approximate Relative Error(%) : '+str(round(relat_err, 4))+'\n'
    file.write(s)
    file.close()
    from matplotlib import pyplot as plt
    plt.grid()
    plt.plot(x_arr, y_arr, 'ro', color= 'blue')
    plt.title("Romberg Algorithm")
    plt.xlabel('x-axis')
    plt.ylabel('f(x)')
    plt.legend(['Data Points'])
    plt.show()
    print s
    return 
def Gn(n):
    from numpy import array
    from numpy.polynomial import legendre  
    if n < 1:
        print "Error: Invalid Input"
        exit
    temp = array([0]*(n+1))
    temp[n] = 1
    z = legendre.legroots(temp)
    w = []
    temp[n] = 0
    temp[n-1] = 1
    for i in z:
        pn_zi =  legendre.legval(i, temp)
        tmp  =  2 *(1-i**2)/((n*pn_zi)**2)
        w.append(tmp)    
    return (z, w)
def Quadrature(f_string, z ,w, a, b ):
    from sympy import symbols, simplify
    x = symbols('x')
    function = simplify(f_string)
    t1 = (b-a)/2
    t2 = (b+a)/2
    s = 0
    for i in range(0, len(z)):
        x_i = z[i]*t1 + t2
        f_x_i= round8(function.subs(x, x_i))
        s = s+w[i]*f_x_i
    return s
def Gauss_Legendre(f_string, a, b, eT):    
    relat_err = 100 #random value
    i = 1
    quadrtr = []
    (z,w) = Gn(i)    
    quadrtr.append(Quadrature(f_string, z, w, a, b))
    while abs(relat_err) > eT:
        i = i+1
        (z,w) = Gn(i)    
        quadrtr.append(Quadrature(f_string, z, w, a, b))
        relat_err = findError(quadrtr[i-1], quadrtr[i-2])
    xi  = []
    t1 = (b-a)/2
    t2 = (b+a)/2
    for i in range(0, len(z)):
        xi.append(z[i]*t1 + t2)
    n = len(quadrtr)
    from sympy import symbols, simplify
    x = symbols('x')
    function = simplify(f_string)
    y_arr = []
    for i in xi:
        y_arr.append(function.subs(x,i))
    fop = raw_input("Enter the O/P filename without extension: ")
    fop = fop.strip()+".txt"
    from matplotlib import pyplot as plt
    plt.grid()
    plt.plot(xi,y_arr,'ro',color= 'black')
    plt.title("Gauss-Legendre Quatrature")
    plt.xlabel('x-axis')
    plt.ylabel('f(x)')
    plt.legend(['Data Points'])
    plt.show()

    file  = open(fop,'w')
    s = '\t\tGauss-Legendre Quatrature\n'
    s = s + '                       I =   '+str(round8(quadrtr[n-1]*t1))
    s= s+ '\nNumber of points used      : '+str(n)
    s= s+ '\nApproximate Relative Error : '+str(round(relat_err, 4))
    file.write(s)
    file.close()
def main():
    from re import split as splt
    f_name = open("inp.txt", "r")
    line_arr = [line for line in f_name]
    tmp = splt('=|!', line_arr[0])
    f_string = tmp[1].strip()
    tmp = splt(',|!', line_arr[1])
    a = float(tmp[0].strip())
    b = float(tmp[1].strip())
    tmp = splt('!', line_arr[2])
    eT = float(tmp[0].strip())  
    tmp = splt('!', line_arr[3])
    option =  int(tmp[0])
    f_name.close
    ##Reading File Over
    if option == 1 :
        Romberg(f_string, a, b, eT)
    elif option == 2:
        Gauss_Legendre(f_string, a, b, eT)
    else:
        print "Invalid Input !!"
if __name__ == '__main__':
    main()    
    